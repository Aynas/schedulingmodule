<?php
session_start();
  // $type=$_POST['type'];
  $username = $_POST['username'];
  $password = $_POST['password'];
 
  if ($username&&$password)
  {
	 $connect = mysqli_connect("localhost", "root", "","insertion")or die("couldn't connect to the database!");
	 // mysqli_select_db("insertion") or die ("couldn't find database!");
	 $query = "SELECT * FROM admin WHERE username='$username' and password='$password' 
	 -- and type='$type'";
	 $result = mysqli_query($connect,$query);
	 
	 $numrows = mysqli_num_rows($result);
	
	 if($numrows!==0)
	 {
		 while($row = mysqli_fetch_assoc($result))
		 {
		 	 // $dbtype=$row['type'];
			 $dbusername = $row['username'];
			 $dbpassword = $row['password'];
		 }
		 if ($username==$dbusername&&($password)==$dbpassword)
		 {
			  echo '<script type="text/javascript">
                      alert("Welcome User!");
                         location="home.php";
                           </script>';
			 $_SESSION['username'] = $username;
		 }
		 else
			 echo '<script type="text/javascript">
                      alert("Wrong Password!");
                         location="index.php";
                           </script>';
	 }	 
	 else
         die('<script type="text/javascript">
                      alert("That uder dont exist!");
                         location="index.php";
                           </script>');		 
	  
  }
  else 
	  die('<script type="text/javascript">
                      alert("Please enter a username and password!");
                         location="tb.php";
                           </script>');
  
	  	 
?>
