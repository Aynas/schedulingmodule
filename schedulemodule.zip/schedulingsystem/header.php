<!DOCTYPE html>
<html>
<head>
	<title>
		Scheduling
	
	</title>
	  <script src="jquery-ui-1.10.4.custom.css" rel="stylesheet"></script>
      <script src="jquery-1.9.1.js"></script>
      <script src="jquery-ui.js"></script>
 
	<!-- Latest Boot Strap compiled and minified CSS
	<script src="script.js"></script>
	<script src="table.js"></script>  -->
	<script src="script.js"></script>

	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" type="text/css" href="styletwo.css">
		
	<link rel="stylesheet" href="css/bootstrap.min.css">
	
	<!-- Optional theme -->
	<script src="css/bootstrap-theme.min.css"></script>
	
	<!-- Latest compiled and minified JavaScript -->
	<script src="js/bootstrap.min.js"></script>
</head>