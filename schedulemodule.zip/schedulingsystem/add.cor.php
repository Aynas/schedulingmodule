<?php 
 
 $con = mysqli_connect ('localhost', 'root', '');
 
 if (!$con)
 {
	 echo 'not connected to server';
 }
 if (!mysqli_select_db($con, 'insertion'))
 {
	 echo 'database not selected';
 }

 $Course_Code = $_POST['corcode'];
 $Course_name = $_POST['corname'];
  $Course_level = $_POST['corlevel'];
  $Course_desc = $_POST['cordesc'];
 
 $sql = "INSERT INTO course (Course_Code, Course_name,Course_Level,Course_desc) VALUES ('$Course_Code', '$Course_name','$Course_level','$Course_desc')";

 if (!mysqli_query ($con, $sql))
 {
	 echo 'not inserted';
 }
 else 
 {
	 echo '<script type="text/javascript">
                      alert("New Course Added!");
                         location="home.php";
                           </script>';
 }


?>